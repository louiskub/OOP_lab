/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export const $ItemsOut = {
    properties: {
        data: {
    type: 'array',
    contains: {
        type: 'ItemOut',
    },
    isRequired: true,
},
        count: {
    type: 'number',
    isRequired: true,
},
    },
} as const;
