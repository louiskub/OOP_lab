/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export const $NewPassword = {
    properties: {
        token: {
    type: 'string',
    isRequired: true,
},
        new_password: {
    type: 'string',
    isRequired: true,
},
    },
} as const;
