/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ItemOut = {
    title: string;
    description?: (string | null);
    id: number;
    owner_id: number;
};
